#!/bin/bash
#set -e
repoPath=$1

# cd $repoPath/Terraform
cd $repoPath
ls -Flah
export VPSUBSCRIPTIONID="b0c7b4cf-0f15-40a7-8a58-86161c0d0e2e"

export ARM_CLIENT_ID=$servicePrincipalId
echo $servicePrincipalId
export ARM_CLIENT_SECRET=$servicePrincipalKey
echo $servicePrincipalKey
export ARM_SUBSCRIPTION_ID=$VPSUBSCRIPTIONID
echo $VPSUBSCRIPTIONID
export ARM_TENANT_ID=$tenantId
echo $tenantId

terraform plan -out testf.tfplan -input=false \
-var-file="./linux_VM_variables.tfvars" 

ls -l
# \
# -var="subscription_id=$VPSUBSCRIPTIONID" \
# -var="tenant_id=$tenantId" \
# -var="client_id=$servicePrincipalId" \
# -var="client_secret=$servicePrincipalKey"