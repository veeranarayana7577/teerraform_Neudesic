#!/bin/bash
#set -e
repoPath=$1

# cd $repoPath/Terraform
cd $repoPath

terraform init -upgrade -input=false \
-backend-config="./backend.tfvars" \
-backend-config="subscription_id=$VPSUBSCRIPTIONID" \
-backend-config="tenant_id=$tenantId" \
-backend-config="client_id=$servicePrincipalId" \
-backend-config="client_secret=$servicePrincipalKey"

terraform workspace new testf 2> /dev/null
terraform workspace select testf