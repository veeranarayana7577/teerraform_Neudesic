#!/bin/bash
#set -e
repoPath=$1

# cd $repoPath/Terraform
cd $repoPath

# az login --service-principal -u ca2a62ae-cb0e-4cbc-8918-14cfebe3f8c0 -p v~6p8F_P-h3oNZ6Ejlf3vY0A~vM9T57eT_ --tenant 687f51c3-0c5d-4905-84f8-97c683a5b9d1

az account show

# export servicePrincipalId=c"a2a62ae-cb0e-4cbc-8918-14cfebe3f8c0"
# export servicePrincipalKey="v~6p8F_P-h3oNZ6Ejlf3vY0A~vM9T57eT_"
export VPSUBSCRIPTIONID="b0c7b4cf-0f15-40a7-8a58-86161c0d0e2e"
# export tenantId="687f51c3-0c5d-4905-84f8-97c683a5b9d1"

export ARM_CLIENT_ID=$servicePrincipalId
echo $servicePrincipalId
export ARM_CLIENT_SECRET=$servicePrincipalKey
echo $servicePrincipalKey
export ARM_SUBSCRIPTION_ID=$VPSUBSCRIPTIONID
echo $VPSUBSCRIPTIONID
export ARM_TENANT_ID=$tenantId
echo $tenantId

terraform init -upgrade -input=false -backend-config="./backend.tfvars"