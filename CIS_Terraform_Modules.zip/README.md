## Plugins version to be used for content development

## Terraform

**Version** - 0.14.6

**Download link** - 

https://releases.hashicorp.com/terraform/0.14.6/terraform_0.14.6_windows_386.zip

https://releases.hashicorp.com/terraform/0.14.6/terraform_0.14.6_windows_amd64.zip


## azurerm

**Version** - 2.46.0

**Sample provider block**

```
terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "=2.46.0"
    }
  }
}
```