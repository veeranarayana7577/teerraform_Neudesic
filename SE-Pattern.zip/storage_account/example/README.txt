This module creates the Storage Account with following features
1.  Option to select Performance i.e Standard or Premium
2.  Option to select Account Kind (Storage V2, Blob Storage etc) and replication (LRS, GRS etc)
3.  Soft Delete Option for blobs, containers and feed
4.  Secure Transfer Required option
5.  Shared key access for all Storage Account created
6.  Minimum TLS Version option
7.  Allow Blob public access option
8.  Option for Tags
9.  Create multiple storage Account
10. Put resource lock to all Storage Account

Improvements required:
1.  Options for SAS creation
2.  Option for different type so SAS creation
3.  Option for resource lock
4.  Connetivity Option such as Public Endpoint, Public Selected Endpoint and Private Endpoint access
5.  Routing Preference Option (Microsoft Or Internet Routing)
6.  Turn on in point restore for containers
7.  Option to turn on versioning for blobs and to change feed
8.  Blob Access Tier option
9.  NFS v3 option
10. Data Lake Storage gen2 heirarchical namespace option
11. Tables and Queues customer managed keys support
12. Check Storage Account Exist or not. Option to update the existing Storage Account



