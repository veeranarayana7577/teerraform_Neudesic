#!/bin/bash
#set -e
repoPath=$1

# cd $repoPath/Terraform

cd $repoPath
terraform apply testf.tfplan