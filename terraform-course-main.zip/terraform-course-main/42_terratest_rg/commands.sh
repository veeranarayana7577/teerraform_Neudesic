export ARM_SUBSCRIPTION_ID=your_subscription_id
# export ARM_TENANT_ID=your_tenant_id
# export ARM_CLIENT_ID=your_app_id
# export ARM_CLIENT_SECRET=your_password

go mod init "tftest"

go test -v