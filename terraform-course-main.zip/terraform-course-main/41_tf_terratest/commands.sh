
go mod init "tftest"

go test -v